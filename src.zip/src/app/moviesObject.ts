
export class movieDetails {

	public title: string;
  public releaseDate: string;

  constructor(title, releaseDate){
    this.releaseDate = releaseDate;
    this.title = title;
  }

}
